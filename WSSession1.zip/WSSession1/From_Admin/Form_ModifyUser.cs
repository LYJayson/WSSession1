﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WSSession1.From_Admin
{
    public partial class Form_ModifyUser : Form
    {
        /// <summary>
        /// 无参构造
        /// </summary>
        public Form_ModifyUser()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 有参构造
        /// </summary>
        /// <param name="User_Name"></param>
        /// <param name="Email_Address"></param>
        public Form_ModifyUser(string User_Name, string Email_Address)
        {
            InitializeComponent();
            this.User_Name = User_Name;
            this.Email_Address = Email_Address;
        }

        /// <summary>
        /// 全局变量
        /// </summary>
        private string _user_name;
        public string User_Name
        {
            get { return _user_name; }
            set { _user_name = value; }
        }
        private string _email_address;
        public string Email_Address
        {
            get { return _email_address; }
            set { _email_address = value; }
        }
        private string _role;
        public string Role
        {
            get { return _role; }
            set { _role = value; }
        }
        private bool _timer;
        public bool Timer
        {
            get { return _timer; }
            set { _timer = value; }
        }

        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close(); //关闭窗体
        }

        private void Btn_Save_Data_Click(object sender, EventArgs e)
        {
            string pat = @"^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$";  // 邮箱正则
            string Sql_Str_Select, Sql_Str_Updata; // 储存sql语句

            IDatabase database = new Mysql(); // new 数据接口对象

            // 判断用户名是否合法
            if (Txt_User_Name.Text.Length <= 0)
            {
                MessageBox.Show("请输入用户名！");
                return;
            }

            //判断 邮箱是否合法
            if (Regex.Replace(Txt_Email_Address.Text, pat, string.Empty) != "") // 判断邮箱是否为合法邮箱
            {
                MessageBox.Show("邮箱有误，请重新输入。");
                Txt_Email_Address.Clear();
                return;
            }

            //判断 是否选择角色
            if (Combo_RoleBox.Text.Length == 0)
            {
                MessageBox.Show("请选择角色！");
                return;
            }
            else if (Combo_RoleBox.Text[0] == 'A')
            {
                Role = "Administrator"; /// 角色
             
                // 修改的sql语句
                Sql_Str_Updata = $"UPDATE userdata SET `User Name`='{Txt_User_Name.Text}',`Email address`='{Txt_Email_Address.Text}',Role='{Role}' WHERE `User Name` = '{User_Name}' and `Email address` = '{Email_Address}'";
               
                database.DataBase_link(); /// 连接
                database.DataBase_modify(ref Sql_Str_Updata); /// 修改

                if (int.Parse(Sql_Str_Updata) > 0)
                {
                    MessageBox.Show("修改成功！");
                }
                else
                {
                    MessageBox.Show("修改失败！");
                    return;
                }
            }
            else
            {
                Role = "User"; /// 角色

                // 查询的sql语句
                Sql_Str_Select = $"SELECT Role FROM userdata WHERE `User Name` = '{User_Name}' AND `Email address` = '{Email_Address}'";
                
                database.DataBase_link();  //连接
                database.DataBase_Inquire(ref Sql_Str_Select); //查询

                if (Sql_Str_Select == Role)
                {
                    /// 修改sql语句
                    Sql_Str_Updata = $"UPDATE userdata SET `User Name`='{Txt_User_Name.Text}',`Email address`='{Txt_Email_Address.Text}',Role='{Role}' WHERE `User Name` = '{User_Name}' and `Email address` = '{Email_Address}'";
                    
                    database.DataBase_modify(ref Sql_Str_Updata); //修改

                    if (int.Parse(Sql_Str_Updata) > 0)
                    {
                        MessageBox.Show("修改成功！");
                    }
                    else
                    {
                        MessageBox.Show("修改失败！");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("管理员不得修改为用户！");
                    Combo_RoleBox.SelectedIndex = 0;  // 将选择控件内容改回管理员
                    return;
                }
            }

        }

        private void Form_ModifyUser_Load(object sender, EventArgs e)
        {
            /// 主窗体值传入
            Txt_User_Name.Text = User_Name;
            Txt_Email_Address.Text = Email_Address;

            Timer_UpData.Start();  // 倒计时开
        }

        private void Timer_UpData_Tick(object sender, EventArgs e)
        {
            if (Timer == true)
            {
                Timer_UpData.Stop(); // 倒计时关

                /// 主窗体值传入
                Txt_User_Name.Text = User_Name;
                Txt_Email_Address.Text = Email_Address;

                Timer = false; // 重置

                Timer_UpData.Start(); // 倒计时开
            }
        }
    }
}
