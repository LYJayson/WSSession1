﻿
namespace WSSession1.From_Admin
{
    partial class Form_AddUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Txt_User_Name = new System.Windows.Forms.TextBox();
            this.Txt_Email_Address = new System.Windows.Forms.TextBox();
            this.Txt_Height = new System.Windows.Forms.TextBox();
            this.Txt_Weight = new System.Windows.Forms.TextBox();
            this.Date_Registration = new System.Windows.Forms.DateTimePicker();
            this.Date_Expiration = new System.Windows.Forms.DateTimePicker();
            this.Combo_RoleBox = new System.Windows.Forms.ComboBox();
            this.Txt_VIP_Number = new System.Windows.Forms.TextBox();
            this.Btn_AddUser = new System.Windows.Forms.Button();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(20, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "会员名称";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(62, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "邮箱";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(331, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "会员卡号";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(62, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "体重";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(331, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "注册日期";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(331, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 21);
            this.label6.TabIndex = 5;
            this.label6.Text = "过期日期";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(373, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 21);
            this.label7.TabIndex = 6;
            this.label7.Text = "角色";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(62, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 21);
            this.label8.TabIndex = 7;
            this.label8.Text = "身高";
            // 
            // Txt_User_Name
            // 
            this.Txt_User_Name.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Txt_User_Name.Location = new System.Drawing.Point(120, 47);
            this.Txt_User_Name.Name = "Txt_User_Name";
            this.Txt_User_Name.Size = new System.Drawing.Size(180, 31);
            this.Txt_User_Name.TabIndex = 8;
            // 
            // Txt_Email_Address
            // 
            this.Txt_Email_Address.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Txt_Email_Address.Location = new System.Drawing.Point(120, 94);
            this.Txt_Email_Address.Name = "Txt_Email_Address";
            this.Txt_Email_Address.Size = new System.Drawing.Size(180, 31);
            this.Txt_Email_Address.TabIndex = 9;
            // 
            // Txt_Height
            // 
            this.Txt_Height.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Txt_Height.Location = new System.Drawing.Point(120, 152);
            this.Txt_Height.Name = "Txt_Height";
            this.Txt_Height.Size = new System.Drawing.Size(180, 31);
            this.Txt_Height.TabIndex = 10;
            // 
            // Txt_Weight
            // 
            this.Txt_Weight.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Txt_Weight.Location = new System.Drawing.Point(120, 206);
            this.Txt_Weight.Name = "Txt_Weight";
            this.Txt_Weight.Size = new System.Drawing.Size(180, 31);
            this.Txt_Weight.TabIndex = 11;
            // 
            // Date_Registration
            // 
            this.Date_Registration.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Date_Registration.Location = new System.Drawing.Point(431, 47);
            this.Date_Registration.MinimumSize = new System.Drawing.Size(20, 20);
            this.Date_Registration.Name = "Date_Registration";
            this.Date_Registration.Size = new System.Drawing.Size(188, 31);
            this.Date_Registration.TabIndex = 18;
            // 
            // Date_Expiration
            // 
            this.Date_Expiration.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Date_Expiration.Location = new System.Drawing.Point(431, 94);
            this.Date_Expiration.MinimumSize = new System.Drawing.Size(20, 20);
            this.Date_Expiration.Name = "Date_Expiration";
            this.Date_Expiration.Size = new System.Drawing.Size(188, 31);
            this.Date_Expiration.TabIndex = 19;
            // 
            // Combo_RoleBox
            // 
            this.Combo_RoleBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combo_RoleBox.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Combo_RoleBox.FormattingEnabled = true;
            this.Combo_RoleBox.Items.AddRange(new object[] {
            "Administrator(管理员)",
            "User(用户)"});
            this.Combo_RoleBox.Location = new System.Drawing.Point(431, 155);
            this.Combo_RoleBox.Name = "Combo_RoleBox";
            this.Combo_RoleBox.Size = new System.Drawing.Size(188, 29);
            this.Combo_RoleBox.TabIndex = 20;
            // 
            // Txt_VIP_Number
            // 
            this.Txt_VIP_Number.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Txt_VIP_Number.Location = new System.Drawing.Point(431, 206);
            this.Txt_VIP_Number.Name = "Txt_VIP_Number";
            this.Txt_VIP_Number.Size = new System.Drawing.Size(188, 31);
            this.Txt_VIP_Number.TabIndex = 21;
            // 
            // Btn_AddUser
            // 
            this.Btn_AddUser.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Btn_AddUser.Location = new System.Drawing.Point(183, 306);
            this.Btn_AddUser.Name = "Btn_AddUser";
            this.Btn_AddUser.Size = new System.Drawing.Size(142, 56);
            this.Btn_AddUser.TabIndex = 22;
            this.Btn_AddUser.Text = "保存";
            this.Btn_AddUser.UseVisualStyleBackColor = true;
            this.Btn_AddUser.Click += new System.EventHandler(this.Btn_AddUser_Click);
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Btn_Exit.Location = new System.Drawing.Point(378, 306);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(142, 56);
            this.Btn_Exit.TabIndex = 23;
            this.Btn_Exit.Text = "取消";
            this.Btn_Exit.UseVisualStyleBackColor = true;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click_1);
            // 
            // Form_AddUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 400);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Btn_AddUser);
            this.Controls.Add(this.Txt_VIP_Number);
            this.Controls.Add(this.Combo_RoleBox);
            this.Controls.Add(this.Date_Expiration);
            this.Controls.Add(this.Date_Registration);
            this.Controls.Add(this.Txt_Weight);
            this.Controls.Add(this.Txt_Height);
            this.Controls.Add(this.Txt_Email_Address);
            this.Controls.Add(this.Txt_User_Name);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("宋体", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Form_AddUser";
            this.Text = "添加用户";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Txt_User_Name;
        private System.Windows.Forms.TextBox Txt_Email_Address;
        private System.Windows.Forms.TextBox Txt_Height;
        private System.Windows.Forms.TextBox Txt_Weight;
        private System.Windows.Forms.DateTimePicker Date_Registration;
        private System.Windows.Forms.DateTimePicker Date_Expiration;
        private System.Windows.Forms.ComboBox Combo_RoleBox;
        private System.Windows.Forms.TextBox Txt_VIP_Number;
        private System.Windows.Forms.Button Btn_AddUser;
        private System.Windows.Forms.Button Btn_Exit;
    }
}