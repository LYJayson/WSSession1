﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WSSession1.From_Admin
{
    public partial class Form_ImportUser : Form
    {
        public Form_ImportUser()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 全局变量
        /// </summary>
        string[] csv_list; // 储存根数据

        private void Txt_Browse_Click(object sender, EventArgs e)
        {
            string Path = @"";

            OpenFileDialog fileDialog = new OpenFileDialog(); // new 资源管理器窗口对象
            DialogResult re = fileDialog.ShowDialog();  // 获取 用户选择

            /// 可能出错的代码
            try
            {
                if (re == DialogResult.OK)
                {
                    Txt_Path.Text = fileDialog.FileName; /// 传入用户选定的路径
                    Path = Txt_Path.Text; /// 传入用户选定的路径
                    csv_list = File.ReadAllLines(Path, Encoding.UTF8);  /// 读取csv数据并转编码传入
                }
                else
                {
                    return;
                }
            }
            catch
            {
                MessageBox.Show("有进程使用该文件中，请等待或者手动关闭它！");
                return;
            }

            /// 打印 csv数据
            RT_Message.SelectionColor = Color.Blue; // 设定输出为蓝色
            RT_Message.AppendText($"数据预览 \n");  // 追加文本
            for (int i = 0; i < csv_list.Length; i++)
            {
                RT_Message.AppendText($"{csv_list[i]}\n");  // 预览数据
            }
        }

        private void Btn_Execution_Click(object sender, EventArgs e)
        {
            IDatabase database = new Mysql(); // new 数据接口对象

            string[] Rows = new string[8]; /// 数据缓存数组
            string Sql_Str_increase, Sql_Str_inquire; // 查询与插入的sql语句变量
            int x = 0; // 缓存索引值

            RT_Message.Clear(); //清空RT文本

            for (int i = 1; i < csv_list.Length - 1; i++)
            {
                string data_list = csv_list[i]; ///根数据
                
                for (int j = 0; j < data_list.Length; j++)
                {
                    if (data_list[j] != ',')
                    {
                        Rows[x] += data_list[j];  // 传入列内容
                    }
                    else
                    {
                        x++;
                    }
                }
                
                string Password = ""; // 储存密码
                
                for (int k = 0; k < Rows[3].Length; k++)
                {
                    Password += Rows[3][k]; // 获取vip id后6位作为密码
                }

                Sql_Str_inquire = $"SELECT `Email address` FROM userdata WHERE `Email address` = '{Rows[2]}';"; /// 查询 导入的用户是否唯一(判断邮箱值唯一)
                Sql_Str_increase = $"INSERT INTO userdata(Role,`User Name`,`Email address`,`Member Number`,`Menber Registration date`,`Menber Expiration date`,Weight,Height,`Password`)" +
                    $"VALUES('{Rows[0]}', '{Rows[1]}', '{Rows[2]}', '{Rows[3]}', '{Rows[4]}', '{Rows[5]}', '{Rows[6]}', '{Rows[7]}', MD5({Password}))"; /// 导入的用户数据sql语句

                database.DataBase_link(); /// 连接数据库
                database.DataBase_Inquire(ref Sql_Str_inquire); /// 查询方法
                if (Sql_Str_inquire != Rows[2])
                {
                    database.DataBase_increase(ref Sql_Str_increase); /// 插入方法
                    if (int.Parse(Sql_Str_increase) > 0)
                    {
                        RT_Message.SelectionColor = Color.Green; // 设定输出为绿色
                        RT_Message.AppendText($"用户Email:{Rows[2]} 导入成功！\n");  // 追加文本
                    }
                    else
                    {
                        RT_Message.SelectionColor = Color.Red; // 设定输出为红色
                        RT_Message.AppendText($"用户Email:{Rows[2]} 导入失败！\n"); // 追加文本
                    }
                }
                else
                {
                    RT_Message.SelectionColor = Color.Red; // 设定输出为红色
                    RT_Message.AppendText($"用户Email:{Rows[2]} 导入失败！\n"); // 追加文本
                }
                for (int m = 0; m < Rows.Length; m++)
                {
                    Rows[m] = ""; // 清空缓存
                }
                x = 0;
            }
            Form_Home.DataGV_Update = true;  // 告诉主窗体导入完成，需要刷新主表dataset
        }

        private void Form_ImportUser_Load(object sender, EventArgs e)
        {

        }
    }
}
