﻿
namespace WSSession1.From_Admin
{
    partial class Form_ModifyUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Txt_User_Name = new System.Windows.Forms.TextBox();
            this.Txt_Email_Address = new System.Windows.Forms.TextBox();
            this.Combo_RoleBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Btn_Save_Data = new System.Windows.Forms.Button();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.Timer_UpData = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // Txt_User_Name
            // 
            this.Txt_User_Name.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Txt_User_Name.Location = new System.Drawing.Point(123, 41);
            this.Txt_User_Name.Name = "Txt_User_Name";
            this.Txt_User_Name.Size = new System.Drawing.Size(162, 31);
            this.Txt_User_Name.TabIndex = 0;
            // 
            // Txt_Email_Address
            // 
            this.Txt_Email_Address.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Txt_Email_Address.Location = new System.Drawing.Point(123, 103);
            this.Txt_Email_Address.Name = "Txt_Email_Address";
            this.Txt_Email_Address.Size = new System.Drawing.Size(162, 31);
            this.Txt_Email_Address.TabIndex = 1;
            // 
            // Combo_RoleBox
            // 
            this.Combo_RoleBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combo_RoleBox.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Combo_RoleBox.FormattingEnabled = true;
            this.Combo_RoleBox.Items.AddRange(new object[] {
            "Administrator(管理员)",
            "User(用户)"});
            this.Combo_RoleBox.Location = new System.Drawing.Point(123, 165);
            this.Combo_RoleBox.Name = "Combo_RoleBox";
            this.Combo_RoleBox.Size = new System.Drawing.Size(162, 29);
            this.Combo_RoleBox.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 15.75F);
            this.label1.Location = new System.Drawing.Point(23, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "会员名称";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 15.75F);
            this.label2.Location = new System.Drawing.Point(65, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 21);
            this.label2.TabIndex = 4;
            this.label2.Text = "邮箱";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 15.75F);
            this.label3.Location = new System.Drawing.Point(65, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 21);
            this.label3.TabIndex = 5;
            this.label3.Text = "角色";
            // 
            // Btn_Save_Data
            // 
            this.Btn_Save_Data.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Btn_Save_Data.Location = new System.Drawing.Point(32, 251);
            this.Btn_Save_Data.Name = "Btn_Save_Data";
            this.Btn_Save_Data.Size = new System.Drawing.Size(117, 48);
            this.Btn_Save_Data.TabIndex = 6;
            this.Btn_Save_Data.Text = "保存";
            this.Btn_Save_Data.UseVisualStyleBackColor = true;
            this.Btn_Save_Data.Click += new System.EventHandler(this.Btn_Save_Data_Click);
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Btn_Exit.Location = new System.Drawing.Point(179, 251);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(117, 48);
            this.Btn_Exit.TabIndex = 7;
            this.Btn_Exit.Text = "取消";
            this.Btn_Exit.UseVisualStyleBackColor = true;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click);
            // 
            // Timer_UpData
            // 
            this.Timer_UpData.Enabled = true;
            this.Timer_UpData.Interval = 3000;
            this.Timer_UpData.Tick += new System.EventHandler(this.Timer_UpData_Tick);
            // 
            // Form_ModifyUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 333);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Btn_Save_Data);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Combo_RoleBox);
            this.Controls.Add(this.Txt_Email_Address);
            this.Controls.Add(this.Txt_User_Name);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Form_ModifyUser";
            this.Text = "修改角色";
            this.Load += new System.EventHandler(this.Form_ModifyUser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Txt_User_Name;
        private System.Windows.Forms.TextBox Txt_Email_Address;
        private System.Windows.Forms.ComboBox Combo_RoleBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Btn_Save_Data;
        private System.Windows.Forms.Button Btn_Exit;
        private System.Windows.Forms.Timer Timer_UpData;
    }
}