﻿
namespace WSSession1.From_Admin
{
    partial class Form_ImportUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Txt_Path = new System.Windows.Forms.TextBox();
            this.Txt_Browse = new System.Windows.Forms.Button();
            this.Btn_Execution = new System.Windows.Forms.Button();
            this.RT_Message = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 15.75F);
            this.label1.Location = new System.Drawing.Point(31, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "文件：";
            // 
            // Txt_Path
            // 
            this.Txt_Path.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Txt_Path.Location = new System.Drawing.Point(110, 39);
            this.Txt_Path.Name = "Txt_Path";
            this.Txt_Path.Size = new System.Drawing.Size(319, 31);
            this.Txt_Path.TabIndex = 1;
            // 
            // Txt_Browse
            // 
            this.Txt_Browse.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Txt_Browse.Location = new System.Drawing.Point(435, 32);
            this.Txt_Browse.Name = "Txt_Browse";
            this.Txt_Browse.Size = new System.Drawing.Size(129, 47);
            this.Txt_Browse.TabIndex = 2;
            this.Txt_Browse.Text = "浏览";
            this.Txt_Browse.UseVisualStyleBackColor = true;
            this.Txt_Browse.Click += new System.EventHandler(this.Txt_Browse_Click);
            // 
            // Btn_Execution
            // 
            this.Btn_Execution.Font = new System.Drawing.Font("宋体", 15.75F);
            this.Btn_Execution.Location = new System.Drawing.Point(570, 32);
            this.Btn_Execution.Name = "Btn_Execution";
            this.Btn_Execution.Size = new System.Drawing.Size(129, 47);
            this.Btn_Execution.TabIndex = 3;
            this.Btn_Execution.Text = "开始导入";
            this.Btn_Execution.UseVisualStyleBackColor = true;
            this.Btn_Execution.Click += new System.EventHandler(this.Btn_Execution_Click);
            // 
            // RT_Message
            // 
            this.RT_Message.Location = new System.Drawing.Point(23, 106);
            this.RT_Message.Name = "RT_Message";
            this.RT_Message.Size = new System.Drawing.Size(694, 306);
            this.RT_Message.TabIndex = 5;
            this.RT_Message.Text = "";
            // 
            // Form_ImportUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 424);
            this.Controls.Add(this.RT_Message);
            this.Controls.Add(this.Btn_Execution);
            this.Controls.Add(this.Txt_Browse);
            this.Controls.Add(this.Txt_Path);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Form_ImportUser";
            this.Text = "用户导入";
            this.Load += new System.EventHandler(this.Form_ImportUser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Txt_Path;
        private System.Windows.Forms.Button Txt_Browse;
        private System.Windows.Forms.Button Btn_Execution;
        private System.Windows.Forms.RichTextBox RT_Message;
    }
}