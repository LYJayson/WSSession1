﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WSSession1.From_Admin;
using MySql.Data.MySqlClient;

namespace WSSession1
{
    public partial class Form_Home : Form
    {
        public Form_Home()
        {
            InitializeComponent();
        }

        private void Form_Home_Load(object sender, EventArgs e)
        {
            DataGV_Update = false;
            DataGridView_Mysql(); // 调用 输出所有用户
        }

        /// <summary>
        /// 全局变量
        /// </summary>
        public Form_ModifyUser form_ModifyUser;
        int Index_Y;
        private static bool _datagv_update;
        public static bool DataGV_Update
        {
            get { return _datagv_update; }
            set { _datagv_update = value; }
        }

        private void Btn_AddUser_Click(object sender, EventArgs e)
        {
            Form_AddUser addUser = new Form_AddUser(); // 开启nenw添加用户空间
            addUser.Show(); // 输出添加用户窗体
        }

        /// <summary>
        /// 输出所有用户
        /// </summary>
        public void DataGridView_Mysql()
        {
            string Sql_Str, Sql_Str_Inquire_User;

            Sql_Str = $"SELECT `User Name` as 'User Name',`Email address` as 'Email',`Member Number` as 'Membership Card ID',DATEDIFF(`Menber Expiration date`,`Menber Registration date`) as '会员时长',Weight as 'Weight',Height as 'Height' FROM userdata"; // 确定规则sql语句
            
            IDatabase database = new Mysql(); // 实例化 数据库接口
            database.DataBase_link(); // 连接数据库
            database.DataBase_Inquire(out DataSet Ds,ref Sql_Str); // 查询

            string[] Days_List = new string[Ds.Tables["userdata"].Rows.Count]; // 储存更新 会员时长
            string[] Level_List = new string[Ds.Tables["userdata"].Rows.Count]; // 储存更新 会员等级

            for (int i = 0; i < Ds.Tables["userdata"].Rows.Count; i++)
            {
                /// 将各各用户天数传入对应数组
                Days_List[i] = Ds.Tables["userdata"].Rows[i]["会员时长"].ToString();
                Level_List[i] = Ds.Tables["userdata"].Rows[i]["会员时长"].ToString();
            }

            for (int i = 0; i < Days_List.Length; i++)
            {
                /// 等级判定
                if (Level_List[i].Length > 0)
                {
                    if (int.Parse(Level_List[i]) >= 30 && int.Parse(Level_List[i]) < 90)   /// 30 - 89
                    {
                        Level_List[i] = "VIP 2";
                    }
                    else if (int.Parse(Level_List[i]) >= 90 && int.Parse(Level_List[i]) < 180)   /// 90 - 179
                    {
                        Level_List[i] = "VIP 3";
                    }
                    else if (int.Parse(Level_List[i]) >= 180 && int.Parse(Level_List[i]) < 270) /// 180 - 269
                    {
                        Level_List[i] = "VIP 4";
                    }
                    else if (int.Parse(Level_List[i]) >= 270 && int.Parse(Level_List[i]) < 360) /// 270 - 359
                    {
                        Level_List[i] = "VIP 5";
                    }
                    else if (int.Parse(Level_List[i]) >= 360) /// 360 - n
                    {
                        Level_List[i] = "SVIP";
                    }
                    else   /// 1 - 29
                    {
                        Level_List[i] = "VIP 1";
                    }
                }
                else
                {
                    Level_List[i] = "Null";
                }

                /// 时长判定
                if (Days_List[i].Length > 0)
                {
                    if (int.Parse(Days_List[i]) > 30 && int.Parse(Days_List[i]) < 365)
                    {
                        Days_List[i] = $"{int.Parse(Days_List[i]) / 30} Month"; //月份
                    }
                    else if (int.Parse(Days_List[i]) > 365)
                    {
                        Days_List[i] = $"{int.Parse(Days_List[i]) / 365} Year"; //年
                    }
                    else
                    {
                        Days_List[i] = $"{Days_List[i]} Days"; //天数
                    }
                }
                else
                {
                    Days_List[i] = "Null";
                }
            }
            
            Ds.Tables["userdata"].Columns.RemoveAt(3); // 直接移除 之后重新插入

            DataColumn dataColumn1 = new DataColumn(); //new 列1对象
            DataColumn dataColumn2 = new DataColumn(); //new 列2对象

            dataColumn1.ColumnName = "Membership Card Duration Time"; // 列名
            dataColumn1.DataType = typeof(string); // 列数据类型
            Ds.Tables["userdata"].Columns.Add(dataColumn1); // 插入空的"Membership Card Duration Time"列
            dataColumn1.SetOrdinal(3); // 将列调整对应索引处

            dataColumn2.ColumnName = "Membership Level"; // 列名
            dataColumn2.DataType = typeof(string); // 列数据类型
            Ds.Tables["userdata"].Columns.Add(dataColumn2); // 插入空的"Membership Level"列
            dataColumn2.SetOrdinal(4); // 将列调整对应索引处

            for (int i = 0; i < Days_List.Length; i++)
            {
                Ds.Tables["userdata"].Rows[i]["Membership Card Duration Time"] = Days_List[i];  /// 插入数据到"Membership Card Duration Time"表
                Ds.Tables["userdata"].Rows[i]["Membership Level"] = Level_List[i];  /// 插入数据到"Membership Level"表
            }


            DataGV.DataSource = Ds; // 数据
            DataGV.DataMember = "userdata"; // 表名

            for (int i = 0; i < DataGV.Rows.Count; i++)
            {
                Sql_Str_Inquire_User = $"SELECT Role FROM userdata WHERE `User Name` = '{DataGV.Rows[i].Cells[0].Value}'";
                database.DataBase_Inquire(ref Sql_Str_Inquire_User); // 查询用户的角色
                if (Sql_Str_Inquire_User == "Administrator")
                {
                    DataGV.Rows[i].DefaultCellStyle.ForeColor = Color.Red; /// Administrator
                }
                else
                {
                    DataGV.Rows[i].DefaultCellStyle.ForeColor = Color.Green; /// User
                }
            }
        }

        /// <summary>
        /// 输出指定用户
        /// </summary>
        public void DataGridView_Mysql(string Role)
        {
            string Sql_Str;
            Sql_Str = $"SELECT `User Name` as 'User Name',`Email address` as 'Email',`Member Number` as 'Membership Card ID',DATEDIFF(`Menber Expiration date`,`Menber Registration date`) as '会员时长',Weight as 'Weight',Height as 'Height' FROM userdata WHERE Role = '{Role}'"; // 确定规则sql语句

            IDatabase database = new Mysql(); // 实例化 数据库接口
            database.DataBase_link(); // 连接数据库
            database.DataBase_Inquire(out DataSet Ds, ref Sql_Str); // 查询

            string[] Days_List = new string[Ds.Tables["userdata"].Rows.Count]; // 储存更新 会员时长
            string[] Level_List = new string[Ds.Tables["userdata"].Rows.Count]; // 储存更新 会员等级

            for (int i = 0; i < Ds.Tables["userdata"].Rows.Count; i++)
            {
                /// 将各各用户天数传入对应数组
                Days_List[i] = Ds.Tables["userdata"].Rows[i]["会员时长"].ToString();
                Level_List[i] = Ds.Tables["userdata"].Rows[i]["会员时长"].ToString();
            }

            for (int i = 0; i < Days_List.Length; i++)
            {
                /// 等级判定
                if (Level_List[i].Length > 0)
                {
                    if (int.Parse(Level_List[i]) >= 30 && int.Parse(Level_List[i]) < 90)   /// 30 - 89
                    {
                        Level_List[i] = "VIP 2";
                    }
                    else if (int.Parse(Level_List[i]) >= 90 && int.Parse(Level_List[i]) < 180)   /// 90 - 179
                    {
                        Level_List[i] = "VIP 3";
                    }
                    else if (int.Parse(Level_List[i]) >= 180 && int.Parse(Level_List[i]) < 270) /// 180 - 269
                    {
                        Level_List[i] = "VIP 4";
                    }
                    else if (int.Parse(Level_List[i]) >= 270 && int.Parse(Level_List[i]) < 360) /// 270 - 359
                    {
                        Level_List[i] = "VIP 5";
                    }
                    else if (int.Parse(Level_List[i]) >= 360) /// 360 - n
                    {
                        Level_List[i] = "SVIP";
                    }
                    else   /// 1 - 29
                    {
                        Level_List[i] = "VIP 1";
                    }
                }
                else
                {
                    Level_List[i] = "Null";
                }

                /// 时长判定
                if (Days_List[i].Length > 0)
                {
                    if (int.Parse(Days_List[i]) > 30 && int.Parse(Days_List[i]) < 365)
                    {
                        Days_List[i] = $"{int.Parse(Days_List[i]) / 30} Month"; //月份
                    }
                    else if (int.Parse(Days_List[i]) > 365)
                    {
                        Days_List[i] = $"{int.Parse(Days_List[i]) / 365} Year"; //年
                    }
                    else
                    {
                        Days_List[i] = $"{Days_List[i]} Days"; //天数
                    }
                }
                else
                {
                    Days_List[i] = "Null";
                }
            }

            Ds.Tables["userdata"].Columns.RemoveAt(3); // 直接移除 之后重新插入

            DataColumn dataColumn1 = new DataColumn(); //new 列1对象
            DataColumn dataColumn2 = new DataColumn(); //new 列2对象

            dataColumn1.ColumnName = "Membership Card Duration Time"; // 列名
            dataColumn1.DataType = typeof(string); // 列数据类型
            Ds.Tables["userdata"].Columns.Add(dataColumn1); // 插入空的"Membership Card Duration Time"列
            dataColumn1.SetOrdinal(3); // 将列调整对应索引处

            dataColumn2.ColumnName = "Membership Level"; // 列名
            dataColumn2.DataType = typeof(string); // 列数据类型
            Ds.Tables["userdata"].Columns.Add(dataColumn2); // 插入空的"Membership Level"列
            dataColumn2.SetOrdinal(4); // 将列调整对应索引处

            for (int i = 0; i < Days_List.Length; i++)
            {
                Ds.Tables["userdata"].Rows[i]["Membership Card Duration Time"] = Days_List[i];  /// 插入数据到"Membership Card Duration Time"表
                Ds.Tables["userdata"].Rows[i]["Membership Level"] = Level_List[i];  /// 插入数据到"Membership Level"表
            }


            DataGV.DataSource = Ds; // 数据
            DataGV.DataMember = "userdata"; // 表名

            if (Role == "Administrator")
            {
                for (int i = 0; i < DataGV.Rows.Count; i++)
                {
                    DataGV.Rows[i].DefaultCellStyle.ForeColor = Color.Red; /// Administrator
                }
            }
            else
            {
                for (int i = 0; i < DataGV.Rows.Count; i++)
                {
                    DataGV.Rows[i].DefaultCellStyle.ForeColor = Color.Green; /// User
                }
            }
        }

        private void 管理员ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridView_Mysql("Administrator"); // 调用 输出指定用户
        }

        private void 所有ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridView_Mysql(); // 调用 输出所有用户
        }

        private void 普通用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridView_Mysql("User"); // 调用 输出指定用户
        }

        private void Btn_ExitSystem_Click(object sender, EventArgs e)
        {
            this.Dispose(); // 退出系统
            Form_Login form_Login = new Form_Login(); // 开启新的登录窗体空间
            form_Login.ShowDialog(); // 输出登录窗体
        }

        private void Change_role_Click(object sender, EventArgs e)
        {

        }

        private void Change_role_DoubleClick(object sender, EventArgs e)
        {

        }

        private void Btn_ModifyUser_Click(object sender, EventArgs e)
        {
            string User_Name = "", Email_Address = "";

            User_Name = DataGV.Rows[Index_Y].Cells[0].Value.ToString();  // 对应索引的值
            Email_Address = DataGV.Rows[Index_Y].Cells[1].Value.ToString(); // 对应索引的值

            form_ModifyUser = new Form_ModifyUser(User_Name, Email_Address);
            form_ModifyUser.Show(); // 输出修改用户窗体
        }

        private void Btn_ModifyViplevel_Click(object sender, EventArgs e)
        {
            DataGridView_Mysql("User"); // 调用 输出指定用户
        }

        private void Btn_ImportUser_Click(object sender, EventArgs e)
        {
            Form_ImportUser form_ImportUser = new Form_ImportUser();
            form_ImportUser.Show(); // 输出导入用户窗体
        }

        private void Data_DoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Index_Y = DataGV.CurrentCell.RowIndex; // 传入用户选择内容对应的Y索引
            form_ModifyUser.User_Name = DataGV.Rows[Index_Y].Cells[0].Value.ToString();  // 对应索引的值
            form_ModifyUser.Email_Address = DataGV.Rows[Index_Y].Cells[1].Value.ToString();  // 对应索引的值
            form_ModifyUser.Timer = true; //告诉 修改窗体 有值传入
        }

        private void Timer_DataGV_Tick(object sender, EventArgs e)
        {
            if (DataGV_Update == true)
            {
                Timer_DataGV.Stop(); // 暂停计时器
                DataGV_Update = false; /// 重置
                DataGridView_Mysql(); // 调用 输出所有用户
                Timer_DataGV.Start(); // 启动计时器
            }
            else
            {
                return;
            }
        }
    }
}
