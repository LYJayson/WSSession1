﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WSSession1.From_Admin
{
    public partial class Form_AddUser : Form
    {
        public Form_AddUser()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random_Number(out string Number); // 初始化 刷新一次
            Txt_VIP_Number.Text = $"{DateTime.Now.Year}{DateTime.Now.Month}{DateTime.Now.Day}{Number}"; //会员id
        }

        private void Btn_Exit_Click_1(object sender, EventArgs e)
        {
            this.Close(); // 取消添加
        }

        private void Btn_AddUser_Click(object sender, EventArgs e)
        {
            string pat = @"^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$";  // 邮箱正则

            string Role, User_Name, Email_Address, Member_Number, Menber_Registration_date = "0000-00-00", Menber_Expiration_date = "0000-00-00", Password;
            string Sql_Str_inquire, Sql_Str_User, Sql_Str_Admin; //接收string的数据
            double Weight = 100, Height = 100; //接收double的数据

            //判断 会员名称是否合法
            if (Txt_User_Name.Text.Length < 0)
            {
                MessageBox.Show("请输入会员名称");
                return;
            }
            else
            {
                User_Name = Txt_User_Name.Text.ToString();
            }

            //判断 邮箱是否合法
            if (Regex.Replace(Txt_Email_Address.Text, pat, string.Empty) != "") // 判断邮箱是否为合法邮箱
            {
                MessageBox.Show("邮箱有误，请重新输入。");
                Txt_Email_Address.Clear();
                return;
            }
            else
            {
                Email_Address = Txt_Email_Address.Text.ToString();
            }

            //判断 是否选择角色
            if (Combo_RoleBox.Text.Length == 0)
            {
                MessageBox.Show("请选择角色！");
                return;
            }
            else if (Combo_RoleBox.Text[0] == 'U')
            {
                Role = "User"; // 用户赋值 用户必选 (身高体重注册日期等)

                //判断 身高是否合法 (cm)
                if (Txt_Height.Text.Length == 0 || int.TryParse(Txt_Height.Text, out _) == false)
                {
                    MessageBox.Show("请正确的身高！");
                    return;
                }
                else if (int.Parse(Txt_Height.Text) > 30 && int.Parse(Txt_Height.Text) < 250)
                {
                    Height = int.Parse(Txt_Height.Text);
                }
                else
                {
                    MessageBox.Show("身高不合法");
                    return;
                }

                //判断 体重是否合法 (斤)
                if (Txt_Weight.Text.Length == 0 || int.TryParse(Txt_Weight.Text, out _) == false)
                {
                    MessageBox.Show("请正确的体重！");
                    return;
                }
                else if (int.Parse(Txt_Weight.Text) > 30 && int.Parse(Txt_Weight.Text) < 300)
                {
                    Weight = int.Parse(Txt_Weight.Text);
                }
                else
                {
                    MessageBox.Show("体重不合法");
                    return;
                }

                //判断 注册日期是否合法
                if (int.Parse(DateTime.Now.Year.ToString()) > int.Parse(Date_Registration.Value.Year.ToString()))
                {
                    Menber_Registration_date = $"{Date_Registration.Value.Year}-{Date_Registration.Value.Month}-{Date_Registration.Value.Day}";
                }
                else if (int.Parse(DateTime.Now.Year.ToString()) == int.Parse(Date_Registration.Value.Year.ToString()))
                {
                    if (int.Parse(DateTime.Now.Month.ToString()) > int.Parse(Date_Registration.Value.Month.ToString()))
                    {
                        Menber_Registration_date = $"{Date_Registration.Value.Year}-{Date_Registration.Value.Month}-{Date_Registration.Value.Day}";
                    }
                    else if (int.Parse(DateTime.Now.Month.ToString()) == int.Parse(Date_Registration.Value.Month.ToString()))
                    {
                        if (int.Parse(DateTime.Now.Day.ToString()) >= int.Parse(Date_Registration.Value.Day.ToString()))
                        {
                            Menber_Registration_date = $"{Date_Registration.Value.Year}-{Date_Registration.Value.Month}-{Date_Registration.Value.Day}";
                        }
                        else
                        {
                            MessageBox.Show("注册日期大于当前日期不合法！");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("注册日期大于当前日期不合法！");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("注册日期大于当前日期不合法！");
                    return;
                }

                //判断 过期日期是否合法
                if (int.Parse(Date_Expiration.Value.Year.ToString()) > int.Parse(Date_Registration.Value.Year.ToString()))
                {
                    Menber_Expiration_date = $"{Date_Expiration.Value.Year}-{Date_Registration.Value.Month}-{Date_Expiration.Value.Day}";
                }
                else if (int.Parse(Date_Expiration.Value.Year.ToString()) == int.Parse(Date_Registration.Value.Year.ToString()))
                {
                    if (int.Parse(Date_Expiration.Value.Month.ToString()) > int.Parse(Date_Registration.Value.Month.ToString()))
                    {
                        Menber_Expiration_date = $"{Date_Expiration.Value.Year}-{Date_Registration.Value.Month}-{Date_Expiration.Value.Day}";
                    }
                    else if (int.Parse(Date_Expiration.Value.Month.ToString()) == int.Parse(Date_Registration.Value.Month.ToString()))
                    {
                        if (int.Parse(Date_Expiration.Value.Day.ToString()) > int.Parse(Date_Registration.Value.Day.ToString()))
                        {
                            Menber_Expiration_date = $"{Date_Expiration.Value.Year}-{Date_Registration.Value.Month}-{Date_Expiration.Value.Day}";
                        }
                        else
                        {
                            MessageBox.Show("过期日期小于注册日期不合法！");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("过期日期小于注册日期不合法！");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("过期日期小于注册日期不合法！");
                    return;
                }
            }
            else
            {
                Role = "Administrator"; // 管理员赋值
            }

            Member_Number = Txt_VIP_Number.Text; // 添加会员id 默认随机
            Password = ""; // 初始化密码
                           // 
            for (int i = Txt_VIP_Number.Text.Length - 6; i < Txt_VIP_Number.Text.Length; i++)
            {
                Password += Txt_VIP_Number.Text[i]; // 会员id后 六位数
            }

            Sql_Str_inquire = $"SELECT `Email address` FROM userdata WHERE `Email address` = '{Email_Address}';"; // 查询 邮箱唯一 inquire_sql语句

            Sql_Str_Admin = $"INSERT INTO userdata(`User Name`,`Email address`,Role,`Member Number`,`Password`)" +
                $"VALUES('{User_Name}', '{Email_Address}', '{Role}', '{Member_Number}', MD5('{Password}'))"; // 插入 Admin_sql语句

            Sql_Str_User = $"INSERT INTO userdata(`User Name`,`Email address`,Height,Weight,`Menber Registration date`,`Menber Expiration date`,Role,`Member Number`,`Password`)" +
                $"VALUES('{User_Name}', '{Email_Address}', '{Height}', '{Weight}', '{Menber_Registration_date}', '{Menber_Expiration_date}', '{Role}', '{Member_Number}', MD5('{Password}'))"; // 插入 User_sql语句
            
            IDatabase database = new Mysql(); // new 数据接口
            database.DataBase_link(); // 连接数据库
            if (Combo_RoleBox.Text[0].ToString() == "A")
            {
                database.DataBase_Inquire(ref Sql_Str_inquire); // 查询Email_Address数据
                if (Sql_Str_inquire == Email_Address)
                {
                    MessageBox.Show("添加失败，所填邮箱已经添加！");
                    return;
                }
                database.DataBase_increase(ref Sql_Str_Admin); // 插入admin数据
                if (int.Parse(Sql_Str_Admin) != 0) //判断 添加与否
                {
                    MessageBox.Show("添加成功！");
                    Form_Home.DataGV_Update = true; // 告诉主窗体添加完成刷新主表dataset
                }
                else
                {
                    MessageBox.Show("添加失败！");
                }
            }
            else
            {
                database.DataBase_Inquire(ref Sql_Str_inquire); // 查询Email_Address数据
                if (Sql_Str_inquire == Email_Address)
                {
                    MessageBox.Show("添加失败，所填邮箱已经添加！");
                    return;
                }
                database.DataBase_increase(ref Sql_Str_User); // 插入User数据
                if (int.Parse(Sql_Str_Admin) != 0) //判断 添加与否
                {
                    MessageBox.Show("添加成功！");
                    Form_Home.DataGV_Update = true; // 告诉主窗体添加完成刷新主表dataset
                }
                else
                {
                    MessageBox.Show("添加失败！");
                }
            }

            Random_Number(out string Number); // 每添加一次刷新一次
            Txt_VIP_Number.Text = $"{DateTime.Now.Year}{DateTime.Now.Month}{DateTime.Now.Day}{Number}"; // 会员id
        }
         
        /// <summary>
        /// 随机数(数字+字母6位)
        /// </summary>
        /// <param name="Number"></param>
        public void Random_Number(out string Number)
        {
            Random random = new Random(); // new 随机数类
            string[] a_z = { "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x", "c", "v", "b", "n", "m" }; // 随机26字母
            Number = "";
            for (int i = 0; i < 3; i++)
            {
                Number += random.Next(0, 9);
                int j = random.Next(0, 25);
                Number += a_z[j];
            }
        }
    }
}
