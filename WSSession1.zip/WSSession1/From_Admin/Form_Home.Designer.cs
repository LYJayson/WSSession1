﻿
namespace WSSession1
{
    partial class Form_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Home));
            this.DataGV = new System.Windows.Forms.DataGridView();
            this.Btn_AddUser = new System.Windows.Forms.ToolStripButton();
            this.Btn_ModifyUser = new System.Windows.Forms.ToolStripButton();
            this.Change_role = new System.Windows.Forms.ToolStripDropDownButton();
            this.普通用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.所有ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.管理员ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Btn_ModifyViplevel = new System.Windows.Forms.ToolStripButton();
            this.Btn_ImportUser = new System.Windows.Forms.ToolStripButton();
            this.Btn_ExitSystem = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Timer_DataGV = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.DataGV)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DataGV
            // 
            this.DataGV.AllowUserToAddRows = false;
            this.DataGV.AllowUserToDeleteRows = false;
            this.DataGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGV.Location = new System.Drawing.Point(28, 63);
            this.DataGV.Name = "DataGV";
            this.DataGV.RowTemplate.Height = 23;
            this.DataGV.Size = new System.Drawing.Size(1022, 498);
            this.DataGV.TabIndex = 1;
            this.DataGV.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Data_DoubleClick);
            // 
            // Btn_AddUser
            // 
            this.Btn_AddUser.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Btn_AddUser.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_AddUser.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Btn_AddUser.Name = "Btn_AddUser";
            this.Btn_AddUser.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.Btn_AddUser.Size = new System.Drawing.Size(98, 30);
            this.Btn_AddUser.Text = "  添加用户  ";
            this.Btn_AddUser.Click += new System.EventHandler(this.Btn_AddUser_Click);
            // 
            // Btn_ModifyUser
            // 
            this.Btn_ModifyUser.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Btn_ModifyUser.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F);
            this.Btn_ModifyUser.Image = ((System.Drawing.Image)(resources.GetObject("Btn_ModifyUser.Image")));
            this.Btn_ModifyUser.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Btn_ModifyUser.Name = "Btn_ModifyUser";
            this.Btn_ModifyUser.Size = new System.Drawing.Size(78, 30);
            this.Btn_ModifyUser.Text = "修改用户";
            this.Btn_ModifyUser.Click += new System.EventHandler(this.Btn_ModifyUser_Click);
            // 
            // Change_role
            // 
            this.Change_role.BackColor = System.Drawing.SystemColors.Control;
            this.Change_role.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Change_role.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.普通用户ToolStripMenuItem,
            this.所有ToolStripMenuItem,
            this.管理员ToolStripMenuItem});
            this.Change_role.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F);
            this.Change_role.Image = ((System.Drawing.Image)(resources.GetObject("Change_role.Image")));
            this.Change_role.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Change_role.Name = "Change_role";
            this.Change_role.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.Change_role.Size = new System.Drawing.Size(87, 30);
            this.Change_role.Text = "更改角色";
            this.Change_role.Click += new System.EventHandler(this.Change_role_Click);
            this.Change_role.DoubleClick += new System.EventHandler(this.Change_role_DoubleClick);
            // 
            // 普通用户ToolStripMenuItem
            // 
            this.普通用户ToolStripMenuItem.Name = "普通用户ToolStripMenuItem";
            this.普通用户ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.普通用户ToolStripMenuItem.Text = "普通用户";
            this.普通用户ToolStripMenuItem.Click += new System.EventHandler(this.普通用户ToolStripMenuItem_Click);
            // 
            // 所有ToolStripMenuItem
            // 
            this.所有ToolStripMenuItem.Name = "所有ToolStripMenuItem";
            this.所有ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.所有ToolStripMenuItem.Text = "所有用户";
            this.所有ToolStripMenuItem.Click += new System.EventHandler(this.所有ToolStripMenuItem_Click);
            // 
            // 管理员ToolStripMenuItem
            // 
            this.管理员ToolStripMenuItem.Name = "管理员ToolStripMenuItem";
            this.管理员ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.管理员ToolStripMenuItem.Text = "管理员";
            this.管理员ToolStripMenuItem.Click += new System.EventHandler(this.管理员ToolStripMenuItem_Click);
            // 
            // Btn_ModifyViplevel
            // 
            this.Btn_ModifyViplevel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Btn_ModifyViplevel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_ModifyViplevel.Image = ((System.Drawing.Image)(resources.GetObject("Btn_ModifyViplevel.Image")));
            this.Btn_ModifyViplevel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Btn_ModifyViplevel.Name = "Btn_ModifyViplevel";
            this.Btn_ModifyViplevel.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.Btn_ModifyViplevel.Size = new System.Drawing.Size(130, 30);
            this.Btn_ModifyViplevel.Text = "  更新会员等级  ";
            this.Btn_ModifyViplevel.Click += new System.EventHandler(this.Btn_ModifyViplevel_Click);
            // 
            // Btn_ImportUser
            // 
            this.Btn_ImportUser.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Btn_ImportUser.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_ImportUser.Image = ((System.Drawing.Image)(resources.GetObject("Btn_ImportUser.Image")));
            this.Btn_ImportUser.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Btn_ImportUser.Name = "Btn_ImportUser";
            this.Btn_ImportUser.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.Btn_ImportUser.Size = new System.Drawing.Size(98, 30);
            this.Btn_ImportUser.Text = "  导入用户  ";
            this.Btn_ImportUser.Click += new System.EventHandler(this.Btn_ImportUser_Click);
            // 
            // Btn_ExitSystem
            // 
            this.Btn_ExitSystem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Btn_ExitSystem.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_ExitSystem.Image = ((System.Drawing.Image)(resources.GetObject("Btn_ExitSystem.Image")));
            this.Btn_ExitSystem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Btn_ExitSystem.Name = "Btn_ExitSystem";
            this.Btn_ExitSystem.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.Btn_ExitSystem.Size = new System.Drawing.Size(98, 30);
            this.Btn_ExitSystem.Text = "  退出系统  ";
            this.Btn_ExitSystem.Click += new System.EventHandler(this.Btn_ExitSystem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Btn_AddUser,
            this.Btn_ModifyUser,
            this.Change_role,
            this.Btn_ModifyViplevel,
            this.Btn_ImportUser,
            this.Btn_ExitSystem});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(1078, 33);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Timer_DataGV
            // 
            this.Timer_DataGV.Enabled = true;
            this.Timer_DataGV.Interval = 10000;
            this.Timer_DataGV.Tick += new System.EventHandler(this.Timer_DataGV_Tick);
            // 
            // Form_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 580);
            this.Controls.Add(this.DataGV);
            this.Controls.Add(this.toolStrip1);
            this.Font = new System.Drawing.Font("宋体", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Form_Home";
            this.Text = "WS健身管理系统";
            this.Load += new System.EventHandler(this.Form_Home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGV)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView DataGV;
        private System.Windows.Forms.ToolStripButton Btn_AddUser;
        private System.Windows.Forms.ToolStripButton Btn_ModifyUser;
        private System.Windows.Forms.ToolStripDropDownButton Change_role;
        private System.Windows.Forms.ToolStripMenuItem 普通用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 所有ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 管理员ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton Btn_ModifyViplevel;
        private System.Windows.Forms.ToolStripButton Btn_ImportUser;
        private System.Windows.Forms.ToolStripButton Btn_ExitSystem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Timer Timer_DataGV;
    }
}